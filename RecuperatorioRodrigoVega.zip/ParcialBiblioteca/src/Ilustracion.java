/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author admin
 */
public class Ilustracion extends Publicacion{
    private String ilustrador;
    private int ancho;
    private int alto;

    public Ilustracion(String ilustrador, int ancho, int alto, String nombre, int AnioPublicacion) {
        super(nombre, AnioPublicacion);
        this.ilustrador = ilustrador;
        this.ancho = ancho;
        this.alto = alto;
    }

    @Override
    public String toString() {
        return "Ilustracion{" + super.toString() + "ilustrador=" + ilustrador + ", ancho=" + ancho + ", alto=" + alto + '}';
    }
    
    
    
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.util.Objects;
/**
 *
 * @author admin
 */
public abstract class Publicacion {
    
    private String nombre;
    private int AnioPublicacion;

    public Publicacion(String nombre, int AnioPublicacion) {
        this.nombre = nombre;
        this.AnioPublicacion = AnioPublicacion;
    }

    public String getNombre() {
        return nombre;
    }

    @Override
    public String toString() {
        return "Publicacion{" + "nombre=" + nombre + ", AnioPublicacion=" + AnioPublicacion + '}';
    }
    
    @Override
    public int hashCode(){
        return Objects.hash(nombre, AnioPublicacion);
    }    
    
    @Override
    public boolean equals(Object obj){
        if(this == obj){
            return true;
        }
        if(obj == null){
            return false;
        }
        if(obj instanceof Publicacion other){
            return nombre.equals(other.nombre) && AnioPublicacion == other.AnioPublicacion;
            
        }
        
        return false;
    }
    
    
    
    
}

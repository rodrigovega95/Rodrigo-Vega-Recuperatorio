
import java.util.ArrayList;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author admin
 */
public class Biblioteca {
    private String nombre;
    private ArrayList<Publicacion> publicaciones;

    public Biblioteca(String nombre) {
        this.nombre = nombre;
        this.publicaciones = new ArrayList<>();
    }
    
    public void agregarPublicacion(Publicacion publicacion){
        if(this.publicaciones.contains(publicacion)){
            throw new PublicacionDuplicadaException();
        }
        this.publicaciones.add(publicacion);
    }
    
    public void mostrarPublicaciones(){
        for(Publicacion publicacion: this.publicaciones){
            System.out.println(publicacion);
        }
    }
    
    public void leerPublicaciones(){
        for(Publicacion publicacion : this.publicaciones){
            if(publicacion instanceof Lectura lector){
                lector.leer();
            }
            else{
                System.out.println(publicacion.getNombre() + " no se puede leer porque es una ilustración.");
            }
        }
    }
    
    
    
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author admin
 */
public class test {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Biblioteca biblioteca = new Biblioteca("Biblioteca de la nacion");
       
       Libro libro = new Libro("JK Rowling",TipoGenero.FICCION,"Harry Potter y eso",2003);
       Revista revista = new Revista(200,"Playboy",2018);
       Ilustracion ilustracion = new Ilustracion("Bansky",500,350,"Yanina Latorre al oleo",1980);
       Ilustracion ilustracion2 = new Ilustracion("Bansky",500,350,"Yanina Latorre al oleo",1980);
        
       try{
           biblioteca.agregarPublicacion(libro);
           biblioteca.agregarPublicacion(revista);
           biblioteca.agregarPublicacion(ilustracion);
           biblioteca.agregarPublicacion(ilustracion2);
                          
                   
       }catch(PublicacionDuplicadaException ex){
           System.out.println(ex);
       }
        
       biblioteca.mostrarPublicaciones();        
       biblioteca.leerPublicaciones();       
       
       
    }
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author admin
 */
public class Libro extends Publicacion implements Lectura {
    
    private String autor;
    private TipoGenero tipoGenero;

    public Libro(String autor, TipoGenero tipoGenero, String nombre, int AnioPublicacion) {
        super(nombre, AnioPublicacion);
        this.autor = autor;
        this.tipoGenero = tipoGenero;
    }

    
    
    @Override
    public String toString() {
        return "Libro{" + super.toString() + "autor=" + autor + ", tipoGenero=" + tipoGenero + '}';
    }
    
    @Override
    public void leer(){
        System.out.println("Se está leyendo el libro " + this.getNombre());
    }
    
    
}

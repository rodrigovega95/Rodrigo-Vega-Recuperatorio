/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author admin
 */
public class Revista extends Publicacion implements Lectura {
    
    private int numeroEdicion;

    public Revista(int numeroEdicion, String nombre, int AnioPublicacion) {
        super(nombre, AnioPublicacion);
        this.numeroEdicion = numeroEdicion;
    }

    @Override
    public String toString() {
        return "Revista{" + super.toString() + "numeroEdicion=" + numeroEdicion + '}';
    }
    
    @Override
    public void leer(){
        System.out.println("Se está leyendo la revista " + this.getNombre());
    }
    
        
    
    
    
}
